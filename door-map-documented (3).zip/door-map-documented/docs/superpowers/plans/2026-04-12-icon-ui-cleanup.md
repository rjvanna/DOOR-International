# Icon UI Cleanup Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Strip all `<small>` sub-description text from buttons, shorten back-button labels to "Back", and add Lucide icons to the Inspector "Clear" and "Copy JSON" buttons — in both `demo.html` and `door-map-plugin3.php`.

**Architecture:** Pure HTML edits only. No CSS, no JS, no logic changes. Both files share the same HTML structure so every change is applied twice (once per file). Tasks are grouped by UI component to keep diffs coherent.

**Tech Stack:** HTML, inline SVG (Lucide icon set, same style already used throughout — `width/height` match context, `stroke-width="2"`, `stroke-linecap="round"`, `stroke-linejoin="round"`)

---

## File Map

| File | What changes |
|---|---|
| `demo.html` | All tasks except Task 4 (security sub-panel is PHP-only) |
| `door-map-plugin3.php` | All tasks |

---

## Task 1: Home screen — remove `<small>` sub-descriptions

**Files:**
- Modify: `demo.html` ~line 125, ~line 129
- Modify: `door-map-plugin3.php` ~line 374, ~line 378

### demo.html

- [ ] **Step 1: Edit Open Map button**

Find:
```html
<span><strong>Open Map</strong><small>Explore world data</small></span>
```
Replace with:
```html
<span><strong>Open Map</strong></span>
```

- [ ] **Step 2: Edit View Options button**

Find:
```html
<span><strong>View Options</strong><small>Settings &amp; tools</small></span>
```
Replace with:
```html
<span><strong>View Options</strong></span>
```

### door-map-plugin3.php

- [ ] **Step 3: Edit Open Map button**

Find:
```html
<span><strong>Open Map</strong><small>Explore interactive world data</small></span>
```
Replace with:
```html
<span><strong>Open Map</strong></span>
```

- [ ] **Step 4: Edit View Options button**

Find:
```html
<span><strong>View Options</strong><small>Settings, tools &amp; view modes</small></span>
```
Replace with:
```html
<span><strong>View Options</strong></span>
```

- [ ] **Step 5: Commit**

```bash
git add demo.html door-map-plugin3.php
git commit -m "ui: remove home screen button sub-descriptions"
```

---

## Task 2: View Options — mode buttons `<small>` removal

**Files:**
- Modify: `demo.html` ~line 153, ~line 158
- Modify: `door-map-plugin3.php` ~line 402, ~line 407, ~line 412

### demo.html

- [ ] **Step 1: Edit Pin Mode button**

Find:
```html
<span class="omg-text"><strong>Pin Mode</strong><small>Show church pins on map</small></span>
```
Replace with:
```html
<span class="omg-text"><strong>Pin Mode</strong></span>
```

- [ ] **Step 2: Edit Standard Mode button**

Find:
```html
<span class="omg-text"><strong>Standard Mode</strong><small>Show country overview</small></span>
```
Replace with:
```html
<span class="omg-text"><strong>Standard Mode</strong></span>
```

### door-map-plugin3.php

- [ ] **Step 3: Edit Pin Mode button**

Find:
```html
<span class="omg-text"><strong>Pin Mode</strong><small>Shows exact church coordinates as pins</small></span>
```
Replace with:
```html
<span class="omg-text"><strong>Pin Mode</strong></span>
```

- [ ] **Step 4: Edit Standard Mode button**

Find:
```html
<span class="omg-text"><strong>Standard Mode</strong><small>Shows region overview &amp; church sidebar</small></span>
```
Replace with:
```html
<span class="omg-text"><strong>Standard Mode</strong></span>
```

- [ ] **Step 5: Edit Mentor Tree button (PHP only)**

Find:
```html
<span class="omg-text"><strong>Mentor Tree</strong><small>Shows the discipleship tree over the map</small></span>
```
Replace with:
```html
<span class="omg-text"><strong>Mentor Tree</strong></span>
```

- [ ] **Step 6: Commit**

```bash
git add demo.html door-map-plugin3.php
git commit -m "ui: remove mode button sub-descriptions from view options"
```

---

## Task 3: View Options — tool buttons `<small>` removal

**Files:**
- Modify: `demo.html` ~lines 170, 175, 180, 185, 190, 195
- Modify: `door-map-plugin3.php` ~lines 424, 429, 434, 439, 444, 449

### demo.html

- [ ] **Step 1: Open Map tool button**

Find:
```html
<span class="otb-text"><strong>Open Map</strong><small>Launch the map</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Open Map</strong></span>
```

- [ ] **Step 2: Add Data tool button**

Find:
```html
<span class="otb-text"><strong>Add Data</strong><small>Add or edit records</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Add Data</strong></span>
```

- [ ] **Step 3: Data Inspector tool button**

Find:
```html
<span class="otb-text"><strong>Data Inspector</strong><small>Browse live database</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Data Inspector</strong></span>
```

- [ ] **Step 4: Dark Mode tool button**

Find:
```html
<span class="otb-text"><strong>Dark Mode</strong><small>Toggle light/dark theme</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Dark Mode</strong></span>
```

- [ ] **Step 5: Pin Security tool button**

Find:
```html
<span class="otb-text"><strong>Pin Security</strong><small>Hide or shift sensitive pins</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Pin Security</strong></span>
```

- [ ] **Step 6: Export Data tool button**

Find:
```html
<span class="otb-text"><strong>Export Data</strong><small>Download data as CSV</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Export Data</strong></span>
```

### door-map-plugin3.php

- [ ] **Step 7: Open Map tool button**

Find:
```html
<span class="otb-text"><strong>Open Map</strong><small>Go to the interactive map view</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Open Map</strong></span>
```

- [ ] **Step 8: Add Data tool button**

Find:
```html
<span class="otb-text"><strong>Add Data</strong><small>Manage countries, churches &amp; staff</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Add Data</strong></span>
```

- [ ] **Step 9: Data Inspector tool button**

Find:
```html
<span class="otb-text"><strong>Data Inspector</strong><small>Live DB browser for groups &amp; contacts</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Data Inspector</strong></span>
```

- [ ] **Step 10: Toggle Dark Mode tool button**

Find:
```html
<span class="otb-text"><strong>Toggle Dark Mode</strong><small>Switch between light and dark theme</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Toggle Dark Mode</strong></span>
```

- [ ] **Step 11: Security tool button**

Find:
```html
<span class="otb-text"><strong>Security</strong><small>Obfuscate or hide sensitive pins</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Security</strong></span>
```

- [ ] **Step 12: Export tool button**

Find:
```html
<span class="otb-text"><strong>Export</strong><small>Download data as CSV files</small></span>
```
Replace with:
```html
<span class="otb-text"><strong>Export</strong></span>
```

- [ ] **Step 13: Commit**

```bash
git add demo.html door-map-plugin3.php
git commit -m "ui: remove tool button sub-descriptions from view options"
```

---

## Task 4: Security sub-panel `<small>` removal (PHP only)

**Files:**
- Modify: `door-map-plugin3.php` ~lines 467, 482

- [ ] **Step 1: Obfuscate Locations row**

Find:
```html
<strong>Obfuscate Locations</strong>
                                            <small>Shift all pins ~15 km from their real position</small>
```
Replace with:
```html
<strong>Obfuscate Locations</strong>
```

- [ ] **Step 2: Hide All Pins row**

Find:
```html
<strong>Hide All Pins</strong>
                                            <small>Remove all church pins from the map</small>
```
Replace with:
```html
<strong>Hide All Pins</strong>
```

- [ ] **Step 3: Commit**

```bash
git add door-map-plugin3.php
git commit -m "ui: remove security sub-panel sub-descriptions"
```

---

## Task 5: Shorten back button text to "Back"

**Files:**
- Modify: `demo.html` ~line 144 (`closeViewOptionsBtn`), ~line 210 (`exportBackBtn`)
- Modify: `door-map-plugin3.php` ~line 392 (`closeViewOptionsBtn`), ~line 770 (`closeFormsPage`), ~line 911 (`exportBackBtn`)

### demo.html

- [ ] **Step 1: View Options back button**

Find:
```html
</svg> Back to Home</button>
```
in the line containing `closeViewOptionsBtn`.
Replace with:
```html
</svg> Back</button>
```

- [ ] **Step 2: Export back button**

Find:
```html
</svg> Back to Options</button>
```
in the line containing `exportBackBtn`.
Replace with:
```html
</svg> Back</button>
```

### door-map-plugin3.php

- [ ] **Step 3: View Options back button**

Find (line ~392):
```html
</svg> Back to Home</button>
```
Replace with:
```html
</svg> Back</button>
```

- [ ] **Step 4: Forms page close button**

Find (line ~770):
```
                Back to Map
```
Replace with:
```
                Back
```

- [ ] **Step 5: Export back button**

Find (line ~911):
```html
</svg> Back to Options</button>
```
Replace with:
```html
</svg> Back</button>
```

- [ ] **Step 6: Commit**

```bash
git add demo.html door-map-plugin3.php
git commit -m "ui: shorten all back button labels to Back"
```

---

## Task 6: Add icons to Inspector "Clear" and "Copy JSON" buttons

**Files:**
- Modify: `demo.html` ~line 293 (`inspClear`), ~line 308 (`inspCopyRaw`)
- Modify: `door-map-plugin3.php` ~line 568 (`inspClear`), ~line 588 (`inspCopyRaw`)

Icon style to match existing inspector buttons: `width="13" height="13"`, `stroke-width="2"`, `stroke-linecap="round"`, `stroke-linejoin="round"`, `fill="none"`, `stroke="currentColor"`.

### demo.html

- [ ] **Step 1: Add trash icon to Clear button**

Find:
```html
<button class="insp-fetch-btn insp-clear"    id="inspClear">Clear</button>
```
Replace with:
```html
<button class="insp-fetch-btn insp-clear"    id="inspClear"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg> Clear</button>
```

- [ ] **Step 2: Add clipboard icon to Copy JSON button**

Find:
```html
<button class="insp-fetch-btn insp-copy" id="inspCopyRaw">Copy JSON</button>
```
Replace with:
```html
<button class="insp-fetch-btn insp-copy" id="inspCopyRaw"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg> Copy JSON</button>
```

### door-map-plugin3.php

- [ ] **Step 3: Add trash icon to Clear button**

Find:
```html
<button class="insp-fetch-btn insp-clear" id="inspClear">Clear</button>
```
Replace with:
```html
<button class="insp-fetch-btn insp-clear" id="inspClear"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/></svg> Clear</button>
```

- [ ] **Step 4: Add clipboard icon to Copy JSON button**

Find:
```html
<button class="insp-fetch-btn insp-copy" id="inspCopyRaw">Copy JSON</button>
```
Replace with:
```html
<button class="insp-fetch-btn insp-copy" id="inspCopyRaw"><svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg> Copy JSON</button>
```

- [ ] **Step 5: Commit**

```bash
git add demo.html door-map-plugin3.php
git commit -m "ui: add trash and clipboard icons to inspector Clear and Copy JSON buttons"
```
