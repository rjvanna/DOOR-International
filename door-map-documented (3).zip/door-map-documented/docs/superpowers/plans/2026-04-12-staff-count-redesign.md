# Staff Count Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Remove the Total Volunteers stat card from the Global Overview modal and replace the always-zero DT-API staff count with a count sourced from the 2x2 Staff CSV, optionally cross-referenced against the live users DB.

**Architecture:** Three files change — `demo.html` and `door-map-plugin3.php` get a new `staffCsvUrl` field in `dtMapData` and lose the volunteers HTML card; `script1.js` gets a new `initStaffCount()` async function that runs silently at page load and writes to `window._staffCount`, which `renderGlobalDashboard()` reads instead of the old `liveData.countryStats.staff` sum.

**Tech Stack:** Vanilla JS (ES2017 async/await), HTML, PHP (WordPress `plugins_url()`)

---

## File Map

| File | What changes |
|---|---|
| `demo.html` | Remove volunteers stat card; add `staffCsvUrl` to `window.dtMapData` |
| `door-map-plugin3.php` | Remove volunteers stat card; add `staffCsvUrl` to `wp_localize_script` array |
| `js/script1.js` | Add `window._staffCount`; add `initStaffCount()`; update `renderGlobalDashboard()`; call `initStaffCount()` in DOMContentLoaded |

---

## Task 1: Remove volunteers stat card from HTML

**Files:**
- Modify: `demo.html` lines 356–360
- Modify: `door-map-plugin3.php` lines 723–731

No tests — visual HTML removal. Verify by opening `demo.html` in a browser and confirming the modal shows 3 stat cards.

### demo.html

- [ ] **Step 1: Remove the volunteers `<div class="stat-card">` block**

Find and delete this entire block (lines 356–360):
```html
                <div class="stat-card">
                    <div class="stat-icon"><span class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></span></div>
                    <div class="stat-value" id="totalVolunteers">0</div>
                    <div class="stat-label">Total Volunteers</div>
                </div>
```

The `</div>` closing `.stat-grid-large` on line 361 stays. Result: `.stat-grid-large` contains exactly 3 `<div class="stat-card">` blocks.

### door-map-plugin3.php

- [ ] **Step 2: Remove the volunteers `<div class="stat-card">` block**

Find and delete this block (lines 723–731):
```html
                    <div class="stat-card">
                        <div class="stat-icon">
                            <span class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                            </span>
                        </div>
                        <div class="stat-value" id="totalVolunteers">0</div>
                        <div class="stat-label">Total Volunteers</div>
                    </div>
```

The `</div>` closing `.stat-grid-large` on line 732 stays.

---

## Task 2: Add `staffCsvUrl` to `dtMapData` in both files

**Files:**
- Modify: `demo.html` ~line 80 (inside `window.dtMapData = { ... }`)
- Modify: `door-map-plugin3.php` ~line 303 (inside `wp_localize_script` array)

### demo.html

- [ ] **Step 1: Add `staffCsvUrl` field to `window.dtMapData`**

Find the `groupPinsEndpoint` line (the last endpoint entry before `dbGroupNames`):
```js
    groupPinsEndpoint:        '',
```
Replace with:
```js
    groupPinsEndpoint:        '',
    staffCsvUrl:              'assets/Copy of Oversight Document - Total 2x2 Staff.csv',
```

### door-map-plugin3.php

- [ ] **Step 2: Add `staffCsvUrl` to `wp_localize_script` array**

Find the `'dbGroupNames'` line (~line 301):
```php
        'dbGroupNames'      => $db_group_names,
```
Replace with:
```php
        'dbGroupNames'      => $db_group_names,
        'staffCsvUrl'       => plugins_url( 'assets/Copy of Oversight Document - Total 2x2 Staff.csv', __FILE__ ),
```

---

## Task 3: Add `initStaffCount()` + update `renderGlobalDashboard()` in script1.js

**Files:**
- Modify: `js/script1.js` ~lines 2121–2133 (`renderGlobalDashboard`)
- Modify: `js/script1.js` — add new function just before `renderGlobalDashboard`

### Step 1: Add module-level `_staffCount` variable and `initStaffCount()` function

- [ ] **Add before `renderGlobalDashboard()` (~line 2121)**

Find this comment line:
```js
function renderGlobalDashboard() {
```

Insert the following block immediately before it:
```js
// Staff count — set asynchronously by initStaffCount(), read by renderGlobalDashboard()
window._staffCount = 0;

/**
 * Load and count unique 2x2 staff from the CSV asset passed via dtMapData.staffCsvUrl.
 *
 * Phase 1 (always): fetch + parse the CSV → build a Set of unique
 *   "firstname|lastname" keys → store count in window._staffCount.
 * Phase 2 (live backend only): if dtMapData.usersEndpoint is set, page through
 *   all users, cross-reference names against the CSV set, and overwrite
 *   window._staffCount with the matched count. If phase 2 fails the CSV
 *   baseline from phase 1 is kept.
 *
 * Called once from DOMContentLoaded. Runs silently in the background.
 */
async function initStaffCount() {
    const csvUrl = window.dtMapData?.staffCsvUrl;
    if (!csvUrl) return;

    // ── Phase 1: parse CSV ────────────────────────────────────────────────────
    let csvNames;
    try {
        const res = await fetch(csvUrl);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const text = await res.text();
        const lines = text.split('\n');
        csvNames = new Set();
        // Row 0 = title ("2x2 Staff…"), row 1 = header ("First name,Last name,…")
        // Data rows start at index 2. Skip rows with an empty first-name column.
        for (let i = 2; i < lines.length; i++) {
            const cols  = lines[i].split(',');
            const first = (cols[0] || '').trim();
            const last  = (cols[1] || '').trim();
            if (!first) continue;
            csvNames.add(first.toLowerCase() + '|' + last.toLowerCase());
        }
        window._staffCount = csvNames.size;
    } catch (err) {
        console.warn('[DoorMap] staff CSV unavailable:', err.message);
        return;
    }

    // ── Phase 2: cross-reference with users endpoint (live backend only) ──────
    const usersUrl = window.dtMapData?.usersEndpoint;
    if (!usersUrl) return;

    try {
        const userKeys = new Set();
        let offset = 0;
        const limit = 25;
        while (true) {
            const res = await fetch(usersUrl + '?limit=' + limit + '&offset=' + offset, {
                headers: { 'X-WP-Nonce': window.dtMapData?.inspectorNonce || '' },
                credentials: 'same-origin'
            });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            const data = await res.json();
            if (!data.posts || !data.posts.length) break;
            data.posts.forEach(u => {
                const first = (u.first_name || '').toLowerCase().trim();
                const last  = (u.last_name  || '').toLowerCase().trim();
                if (first) userKeys.add(first + '|' + last);
            });
            if (userKeys.size >= (data.total || userKeys.size)) break;
            offset += limit;
        }
        window._staffCount = [...csvNames].filter(k => userKeys.has(k)).length;
    } catch (err) {
        console.warn('[DoorMap] users cross-reference unavailable — using CSV count:', err.message);
        // Phase 1 baseline in window._staffCount is kept
    }
}

```

### Step 2: Update `renderGlobalDashboard()`

- [ ] **Replace the body of `renderGlobalDashboard()` (~lines 2121–2133)**

Find:
```js
function renderGlobalDashboard() {
    const el = id => document.getElementById(id);
    // Active Countries = countries that have at least one DT group (independent of level override)
    const activeCountryNames = Object.keys(liveData.countryStats).filter(k => (liveData.countryStats[k].groups || 0) > 0).sort();
    if (el('totalCountries')) el('totalCountries').textContent = activeCountryNames.length;
    // Country list shows the same set
    if (el('countryList')) el('countryList').innerHTML = activeCountryNames.map(n => `<li>${escapeHtml(n)}</li>`).join('');
    let tG=0, tS=0, tV=0;
    Object.values(liveData.countryStats).forEach(s => { tG+=s.groups||0; tS+=s.staff||0; tV+=s.volunteers||0; });
    if (el('totalGroups'))     el('totalGroups').textContent    = tG;
    if (el('totalStaff'))      el('totalStaff').textContent     = tS;
    if (el('totalVolunteers')) el('totalVolunteers').textContent = tV;
}
```

Replace with:
```js
function renderGlobalDashboard() {
    const el = id => document.getElementById(id);
    // Active Countries = countries that have at least one DT group (independent of level override)
    const activeCountryNames = Object.keys(liveData.countryStats).filter(k => (liveData.countryStats[k].groups || 0) > 0).sort();
    if (el('totalCountries')) el('totalCountries').textContent = activeCountryNames.length;
    // Country list shows the same set
    if (el('countryList')) el('countryList').innerHTML = activeCountryNames.map(n => `<li>${escapeHtml(n)}</li>`).join('');
    let tG = 0;
    Object.values(liveData.countryStats).forEach(s => { tG += s.groups || 0; });
    if (el('totalGroups')) el('totalGroups').textContent = tG;
    if (el('totalStaff'))  el('totalStaff').textContent  = window._staffCount ?? 0;
}
```

---

## Task 4: Wire `initStaffCount()` into DOMContentLoaded

**Files:**
- Modify: `js/script1.js` ~lines 2630–2635

- [ ] **Step 1: Add `initStaffCount()` call to DOMContentLoaded handler**

Find:
```js
document.addEventListener('DOMContentLoaded', function() {
    seedCountriesFromCSV(); // pre-populate from CSV so shapes render before DT data arrives
    setupEventListeners();
    initTheme();
    renderGlobalDashboard();
});
```

Replace with:
```js
document.addEventListener('DOMContentLoaded', function() {
    seedCountriesFromCSV(); // pre-populate from CSV so shapes render before DT data arrives
    setupEventListeners();
    initTheme();
    initStaffCount(); // async — populates window._staffCount before user opens Overview modal
    renderGlobalDashboard();
});
```

- [ ] **Step 2: Verify in browser**

Open `demo.html` via the local server (`serve.bat` or `python serve.py`). Click the Global Overview button. Confirm:
- 3 stat cards visible (Active Countries, Total Groups, Total Staff) — no Volunteers card
- Total Staff shows a non-zero number (~53, the count of unique named rows in the CSV)
- Open browser console — no errors, one `[DoorMap] staff CSV unavailable` warning is acceptable only if the server isn't serving the assets folder
