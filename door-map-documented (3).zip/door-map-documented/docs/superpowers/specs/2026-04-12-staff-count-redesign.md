# Staff Count Redesign — Design Spec
**Date:** 2026-04-12
**Status:** Approved

## Goal

Replace the always-zero DT-API-derived staff count in the Global Overview modal with a count sourced from the 2x2 Staff CSV asset, optionally cross-referenced against the live users DB for accuracy. Remove the volunteers stat card entirely.

---

## Part 1 — Remove Volunteers Stat Card

### HTML (demo.html and door-map-plugin3.php)

Remove the entire `<div class="stat-card">` block containing `#totalVolunteers` from `#globalOverviewModal`. The `.stat-grid-large` grid goes from 4 cards to 3 (Active Countries, Total Groups, Total Staff).

### JS (script1.js — `renderGlobalDashboard()`)

Remove the `tV` variable and the `tV += s.volunteers || 0` accumulation line. Remove the `el('totalVolunteers').textContent = tV` assignment. No other changes to this function.

---

## Part 2 — CSV-Based Staff Count

### New `dtMapData` field

Both `demo.html` and `door-map-plugin3.php` add a `staffCsvUrl` entry to `window.dtMapData`:

- **demo.html**: `staffCsvUrl: 'assets/Copy of Oversight Document - Total 2x2 Staff.csv'`
- **door-map-plugin3.php**: `staffCsvUrl: plugins_url('assets/Copy of Oversight Document - Total 2x2 Staff.csv', __FILE__)`

### New function: `initStaffCount()` in script1.js

Called once on `DOMContentLoaded` (alongside existing init logic). Runs two parallel async operations via `Promise.all` (the users branch is skipped if `USERS_ENDPOINT` is empty):

#### CSV parse branch (always runs)

```
fetch(dtMapData.staffCsvUrl)
  → text()
  → split('\n')
  → skip row 0 (title: "2x2 Staff…")
  → skip row 1 (header: "First name,Last name…")
  → for each remaining row:
      split(',')
      col0 = first name (trim)
      col1 = last name  (trim)
      skip if col0 is empty
      key  = col0.toLowerCase() + '|' + col1.toLowerCase()
      add to Set<string> csvNames
  → window._staffCount = csvNames.size
```

#### Users cross-reference branch (only if USERS_ENDPOINT is non-empty)

```
fetch all users pages from USERS_ENDPOINT (same pagination as inspector.js runFetchUsers)
  → for each user record:
      key = (user.first_name || '').toLowerCase().trim()
          + '|'
          + (user.last_name  || '').toLowerCase().trim()
      add to Set<string> userKeys
  → matched = [...csvNames].filter(k => userKeys.has(k))
  → window._staffCount = matched.length
```

Both branches store their result in `window._staffCount`. The CSV branch runs first (fast, local asset) and sets an immediate baseline. The users branch overwrites it when the network call completes. If the users fetch fails (network error, non-ok response), the CSV baseline is kept — the error is logged to console but not surfaced to the user.

### Updated `renderGlobalDashboard()`

Replace:
```js
let tG=0, tS=0, tV=0;
Object.values(liveData.countryStats).forEach(s => { tG+=s.groups||0; tS+=s.staff||0; tV+=s.volunteers||0; });
if (el('totalGroups'))     el('totalGroups').textContent    = tG;
if (el('totalStaff'))      el('totalStaff').textContent     = tS;
if (el('totalVolunteers')) el('totalVolunteers').textContent = tV;
```

With:
```js
let tG = 0;
Object.values(liveData.countryStats).forEach(s => { tG += s.groups || 0; });
if (el('totalGroups')) el('totalGroups').textContent = tG;
if (el('totalStaff'))  el('totalStaff').textContent  = window._staffCount ?? 0;
```

---

## Name Matching Rules

| Rule | Detail |
|---|---|
| Case | Both sides lowercased before comparison |
| Whitespace | Both sides `.trim()`'d — CSV has trailing spaces on some entries |
| CSV col 0 | First name (may be multi-word: "Beshir Mohammed", "Pankajkumar Mohanlal") |
| CSV col 1 | Last name |
| Users field | `first_name` and `last_name` from the users endpoint response |
| Match key | `first_name.toLowerCase().trim() + '\|' + last_name.toLowerCase().trim()` |

---

## Demo Mode Behaviour

`USERS_ENDPOINT` is empty in `demo.html` → only the CSV branch runs → `window._staffCount` = number of unique named rows in the CSV (expected: ~53).

---

## Error Handling

| Scenario | Behaviour |
|---|---|
| CSV fetch fails (404, network) | `window._staffCount` stays `0`, error logged to console |
| Users fetch fails after CSV succeeds | CSV baseline count is kept, error logged to console |
| `staffCsvUrl` not set | `initStaffCount()` exits early, count stays `0` |

---

## What Is NOT Changing

- All other stat cards (Active Countries, Total Groups) — unchanged
- The country list, export button, `toggleCountryList` — unchanged
- Inspector panel, data management forms — unchanged
- CSS — no changes needed (3-card grid reflows automatically via existing `stat-grid-large` flex/grid rules)
