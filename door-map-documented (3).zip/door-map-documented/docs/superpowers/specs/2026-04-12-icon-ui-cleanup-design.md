# Icon UI Cleanup — Design Spec
**Date:** 2026-04-12
**Status:** Approved

## Goal
Make the plugin UI more icon-based by stripping all `<small>` sub-description text from buttons and cleaning up verbose back-button labels. Two inspector buttons ("Clear", "Copy JSON") currently have no icons — add matching ones.

## Scope
Changes apply to **two files**:
- `demo.html` — standalone demo page
- `door-map-plugin3.php` — production WordPress plugin (same HTML structure)

No CSS changes. No JS changes. No layout changes.

---

## Part 1 — Remove all `<small>` sub-descriptions from buttons

Every `<small>` element nested inside a button's text span is deleted outright. The button label (`<strong>`) and icon are retained.

### Home screen (`#homeScreen`)
| Button | Remove |
|---|---|
| Open Map | `<small>Explore world data</small>` / `<small>Explore interactive world data</small>` |
| View Options | `<small>Settings & tools</small>` / `<small>Settings, tools & view modes</small>` |

### View Options — Map Viewing Mode (`.opts-mode-btn`)
| Button | Remove |
|---|---|
| Pin Mode | `<small>Show church pins on map</small>` / `<small>Shows exact church coordinates as pins</small>` |
| Standard Mode | `<small>Show country overview</small>` / `<small>Shows region overview & church sidebar</small>` |
| Mentor Tree (PHP only) | `<small>Shows the discipleship tree over the map</small>` |

### View Options — Tools & Actions (`.opts-tool-btn`)
| Button | Remove |
|---|---|
| Open Map | `<small>Launch the map</small>` / `<small>Go to the interactive map view</small>` |
| Add Data | `<small>Add or edit records</small>` / `<small>Manage countries, churches & staff</small>` |
| Data Inspector | `<small>Browse live database</small>` / `<small>Live DB browser for groups & contacts</small>` |
| Dark Mode / Toggle Dark Mode | `<small>Toggle light/dark theme</small>` / `<small>Switch between light and dark theme</small>` |
| Pin Security / Security | `<small>Hide or shift sensitive pins</small>` / `<small>Obfuscate or hide sensitive pins</small>` |
| Export Data / Export | `<small>Download data as CSV</small>` / `<small>Download data as CSV files</small>` |

### Security sub-panel (PHP only — `.sec-text small`)
| Option | Remove |
|---|---|
| Obfuscate | `<small>Shift all pins ~15 km from their real position</small>` |
| Hide Pins | `<small>Remove all church pins from the map</small>` |

---

## Part 2 — Shorten back button text

All back buttons already have a left-arrow SVG icon. Text trimmed to "Back".

| Element | Before | After |
|---|---|---|
| `#closeViewOptionsBtn` | "Back to Home" | "Back" |
| `#exportBackBtn` | "Back to Options" | "Back" |
| `#closeFormsPage` (demo) | "Back" | unchanged |
| Forms page back button (PHP) | "Back to Map" | "Back" |

---

## Part 3 — Add icons to Inspector buttons

Both buttons are in `.insp-controls` alongside Groups/Contacts/Users which already use Lucide SVGs at `width="13" height="13"`, `stroke-width="2"`, `stroke-linecap="round"`, `stroke-linejoin="round"`. New icons use the identical style.

| Button | Icon | SVG path description |
|---|---|---|
| `#inspClear` | Trash-2 (bin with lid) | `<polyline points="3 6 5 6 21 6"/>` + bin body + two inner lines |
| `#inspCopyRaw` | Clipboard | Two overlapping rects with a small rect at top |

Icon is prepended inside the button, before the text label, matching the Groups/Contacts/Users pattern exactly.

---

## What is NOT changing
- Toolbar control button labels ("Global Overview", "Security: Off", "Add Data", "Dark Mode", "Data Inspector", "Back") — already short, stay as-is
- Home screen mode badge ("Standard Mode active" / "Pin Mode active") — stays as-is
- Section labels "Map Viewing Mode" and "Tools & Actions" — stays as-is
- All CSS — no changes
- All JS — no changes
- Form field labels, section headers, legend — not in scope
