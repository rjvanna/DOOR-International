<?php
/**
 * Plugin Name: DOOR International Global Ministry Map
 * Description: A Leaflet.js based map for visualizing global ministry data, integrated with DiscipleTools.
 * Version: 3.0.0
 * Author: Rylan Vannaman & Evan Simons
 */

// Prevent direct access to the file for security
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 1. Enqueue Assets and Pass Security Nonce to JavaScript
 */
function door_map_enqueue_assets() {
    // Load Leaflet CSS & JS from CDN
    wp_enqueue_style('leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
    wp_enqueue_script('leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), null, true);
    
    // Load Custom CSS
    wp_enqueue_style('door-map-styles', plugins_url('css/styles.css', __FILE__));
    
    // Load Custom JS (depends on leaflet-js)
    wp_enqueue_script('door-map-script', plugins_url('js/script.js', __FILE__), array('leaflet-js'), '3.0.0', true);

    // CRITICAL: Pass the WordPress REST API URL and Security Nonce to our JavaScript
    wp_localize_script('door-map-script', 'dtMapData', array(
        'root'  => esc_url_raw(rest_url()),
        'nonce' => wp_create_nonce('wp_rest'),
        'canCreateGroups'   => current_user_can('edit_posts') ? 'true' : 'false',
        'canCreateContacts' => current_user_can('edit_posts') ? 'true' : 'false'
    ));
}
// Load assets on the frontend
add_action('wp_enqueue_scripts', 'door_map_enqueue_assets');
// Load assets on the backend (Admin) so the map works in the Extensions menu
add_action('admin_enqueue_scripts', 'door_map_enqueue_assets');

/**
 * 2. Create the Shortcode to inject the HTML UI
 */
function door_map_shortcode() {
    ob_start(); // Start gathering the HTML output
    ?>
    
    <style>
        .icon { display:inline-flex; align-items:center; justify-content:center; flex-shrink:0; }
        .icon svg { display:block; }
        .btn-icon .icon { pointer-events:none; }
        .card-icon .icon svg { width:36px; height:36px; stroke-width:1.5; }
        .stat-icon .icon svg { width:28px; height:28px; stroke-width:1.5; }
    </style>

    <div class="container">
        
        <button id="globalOverviewBtn" class="control-btn overview-btn" title="View Global Statistics">
            <span class="btn-icon">
                <span class="icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                </span>
            </span>
            <span class="btn-text">Global Overview</span>
        </button>
        
        <div class="security-wrap">
            <button id="obscurePinsBtn" class="control-btn security-btn" title="10/40 Window Security Options">
                <span class="btn-icon">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    </span>
                </span>
                <span class="btn-text">Security: Off</span>
            </button>
            <div id="securityPopup" class="security-popup">
                <div class="popup-header">
                    <h4>
                        <span class="icon" style="display:inline-flex;vertical-align:middle;margin-right:6px;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        </span>
                        10/40 Window Pin Security
                    </h4>
                    <p>Applies only to church pins inside the 10/40 Window (10°–40°N, 10°W–145°E)</p>
                </div>
                <button class="sec-option" data-mode="obfuscate">
                    <span class="sec-icon icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </span>
                    <div class="sec-text">
                        <strong>Obfuscate Locations</strong>
                        <small>Shift pins ~15 km from their real position</small>
                    </div>
                </button>
                <button class="sec-option" data-mode="hidden">
                    <span class="sec-icon icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    </span>
                    <div class="sec-text">
                        <strong>Hide Pins</strong>
                        <small>Remove 10/40 church pins from the map</small>
                    </div>
                </button>
                <p class="sec-reset">Click the active option again to reset to normal.</p>
            </div>
        </div>
        
        <button id="addDataBtn" class="control-btn data-btn" title="Data Management Dashboard">
            <span class="btn-icon">
                <span class="icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                </span>
            </span>
            <span class="btn-text">Add Data</span>
        </button>

        <button id="themeToggleBtn" class="control-btn theme-btn" title="Toggle Dark Mode">
            <span class="btn-icon">
                <span class="icon" id="themeIcon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
                </span>
            </span>
            <span class="btn-text">Dark Mode</span>
        </button>

        <div id="map" class="map-container"></div>

        <div class="map-legend">
            <h4>Country Status</h4>
            <div class="legend-item">
                <span class="legend-color" style="background: #2196f3"></span>
                <span>L1 &mdash; Established</span>
            </div>
            <div class="legend-item">
                <span class="legend-color" style="background: #8bc34a"></span>
                <span>L2 &mdash; Growing</span>
            </div>
            <div class="legend-item">
                <span class="legend-color" style="background: #ffeb3b"></span>
                <span>L3 &mdash; Developing</span>
            </div>
            <div class="legend-item">
                <span class="legend-color" style="background: #ff9800"></span>
                <span>L4 &mdash; Emerging</span>
            </div>
            <div class="legend-item">
                <span class="legend-color" style="background: #9e9e9e"></span>
                <span>Inactive</span>
            </div>
            <div class="legend-item">
                <span class="legend-color" style="background: #f44336"></span>
                <span>Cancelled</span>
            </div>
        </div>

        <div class="branding">
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0">
                <rect width="22" height="22" rx="4" fill="#db5729"/>
                <text x="11" y="16" text-anchor="middle" font-family="Raleway,sans-serif" font-weight="800" font-size="14" fill="white">D</text>
            </svg>
            <span class="brand-text">DOOR International</span>
            <span class="brand-subtitle">Ministry Map</span>
        </div>
    </div>

    <div id="globalOverviewModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <span class="icon" style="display:inline-flex;vertical-align:middle;margin-right:8px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    </span>
                    Global Ministry Overview
                </h2>
                <button class="modal-close" id="closeOverview" aria-label="Close modal">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            <div class="modal-body">
                <div class="stat-grid-large">
                    <div class="stat-card">
                        <div class="stat-icon">
                            <span class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                            </span>
                        </div>
                        <div class="stat-value" id="totalCountries">0</div>
                        <div class="stat-label">Active Countries</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <span class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                            </span>
                        </div>
                        <div class="stat-value" id="totalChurches">0</div>
                        <div class="stat-label">Total Churches</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <span class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                            </span>
                        </div>
                        <div class="stat-value" id="totalGroups">0</div>
                        <div class="stat-label">Total Groups</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <span class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            </span>
                        </div>
                        <div class="stat-value" id="totalStaff">0</div>
                        <div class="stat-label">Total Staff</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon">
                            <span class="icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                            </span>
                        </div>
                        <div class="stat-value" id="totalVolunteers">0</div>
                        <div class="stat-label">Total Volunteers</div>
                    </div>
                </div>
                
                <button id="toggleCountryList" class="toggle-list-btn">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                    </span>
                    Show Country List
                </button>
                <ul id="countryList" class="country-list"></ul>
                
                <div class="modal-actions">
                    <button class="action-btn" id="exportGlobalCSV" title="Export global statistics">
                        <span class="icon" style="display:inline-flex;vertical-align:middle;margin-right:6px;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        </span>
                        Export to CSV
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div id="formsPage" class="forms-page">
        <div class="forms-header">
            <div class="forms-title">
                <h2>
                    <span class="icon" style="display:inline-flex;vertical-align:middle;margin-right:8px;margin-bottom:2px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                    </span>
                    Data Management
                </h2>
                <p class="forms-subtitle">Add, edit, or update ministry data &mdash; session only, data resets on refresh</p>
            </div>
            <button id="closeFormsPage" class="close-forms-btn">
                <span class="icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
                </span>
                Back to Map
            </button>
        </div>
        
        <div class="form-selection-cards">
            <div class="form-card active" data-target="addCountrySection">
                <div class="card-icon">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                    </span>
                </div>
                <h3>Add Country</h3>
                <p>Register a new ministry country</p>
            </div>
            <div class="form-card" data-target="addChurchSection">
                <div class="card-icon">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    </span>
                </div>
                <h3>Add Church</h3>
                <p>Add a church location</p>
            </div>
            <div class="form-card" data-target="addStaffSection">
                <div class="card-icon">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </span>
                </div>
                <h3>Add Staff</h3>
                <p>Register a staff member</p>
            </div>
            <div class="form-card" data-target="updateLevelSection">
                <div class="card-icon">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                    </span>
                </div>
                <h3>Update Status</h3>
                <p>Change country color coding</p>
            </div>
            <div class="form-card" data-target="editChurchSection">
                <div class="card-icon">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </span>
                </div>
                <h3>Edit Church</h3>
                <p>Modify existing church data</p>
            </div>
            <div class="form-card" data-target="editStaffSection">
                <div class="card-icon">
                    <span class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </span>
                </div>
                <h3>Edit Staff</h3>
                <p>Update staff info &amp; tracking</p>
            </div>
        </div>

        <div class="form-sections-container">
            
            <div id="addCountrySection" class="form-section active">
                <div class="form-section-header">
                    <h3>Add a New Country</h3>
                    <p>Register a new country for ministry tracking</p>
                </div>
                <form id="formAddCountry">
                    <div class="form-group">
                        <label for="addCountryName">Country Name</label>
                        <input type="text" id="addCountryName" required 
                               placeholder="e.g. Germany" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="addCountryCode">Country Code (2-letters)</label>
                        <input type="text" id="addCountryCode" required 
                               placeholder="e.g. de" maxlength="2" 
                               style="text-transform: lowercase;" autocomplete="off">
                    </div>
                    <button type="submit" class="submit-btn">Add Country</button>
                </form>
            </div>
            
            <div id="addChurchSection" class="form-section">
                <div class="form-section-header">
                    <h3>Add a New Church</h3>
                    <p>Register a church location within a country</p>
                </div>
                <form id="formAddChurch">
                    <div class="form-group">
                        <label for="churchCountrySelect">Select Country</label>
                        <select id="churchCountrySelect" required class="form-control">
                            <option value="">-- Choose Country --</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="addChurchState">State / Region Name</label>
                        <input type="text" id="addChurchState" required 
                               placeholder="e.g. Bavaria" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="addChurchName">Church Name</label>
                        <input type="text" id="addChurchName" required 
                               placeholder="e.g. Munich Fellowship" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label>Click on the map to set the exact church location</label>
                        <div id="addChurchMap" class="mini-map"></div>
                        <input type="hidden" id="addChurchLat">
                        <input type="hidden" id="addChurchLng">
                        <p id="selectedCoordsText" class="coords-text">No location selected yet — click the map to place a pin.</p>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="addChurchYear">Year Started</label>
                            <input type="number" id="addChurchYear" 
                                   placeholder="2024" min="1900" max="2100">
                        </div>
                        <div class="form-group">
                            <label for="addChurchAttendees">Attendees</label>
                            <input type="number" id="addChurchAttendees" 
                                   placeholder="50" min="0">
                        </div>
                    </div>
                    <button type="submit" class="submit-btn">Add Church</button>
                </form>
            </div>
            
            <div id="addStaffSection" class="form-section">
                <div class="form-section-header">
                    <h3>Add Staff Member</h3>
                    <p>Register a new staff member and track discipleship progress</p>
                </div>
                <form id="formAddStaff">
                    <div class="form-group">
                        <label for="staffChurchSelect">Assign to Church</label>
                        <select id="staffChurchSelect" required class="form-control">
                            <option value="">-- Choose Church --</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="addStaffName">Staff Name</label>
                        <input type="text" id="addStaffName" required 
                               placeholder="e.g. John Doe" autocomplete="off">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="addStaffAge">Age</label>
                            <input type="number" id="addStaffAge" 
                                   placeholder="30" min="18" max="120">
                        </div>
                        <div class="form-group">
                            <label for="addStaffYear">Year Joined</label>
                            <input type="number" id="addStaffYear" 
                                   placeholder="2024" min="1900" max="2100">
                        </div>
                    </div>
                    <div class="discipleship-tracker">
                        <h4>Discipleship Progress Tracker</h4>
                        <p>Select the highest level achieved for each milestone</p>
                        <div class="form-row discipleship-row">
                            <div class="form-group">
                                <label for="addStaffEvangelism">Evangelism</label>
                                <select id="addStaffEvangelism" class="form-control">
                                    <option value="None">None</option>
                                    <option value="Model">Model</option>
                                    <option value="Assist">Assist</option>
                                    <option value="Watch">Watch</option>
                                    <option value="Leader">Leader</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="addStaffSalvation">Salvation</label>
                                <select id="addStaffSalvation" class="form-control">
                                    <option value="None">None</option>
                                    <option value="Model">Model</option>
                                    <option value="Assist">Assist</option>
                                    <option value="Watch">Watch</option>
                                    <option value="Leader">Leader</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="addStaffBaptism">Baptism</label>
                                <select id="addStaffBaptism" class="form-control">
                                    <option value="None">None</option>
                                    <option value="Model">Model</option>
                                    <option value="Assist">Assist</option>
                                    <option value="Watch">Watch</option>
                                    <option value="Leader">Leader</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="submit-btn">Add Staff Member</button>
                </form>
            </div>
            
            <div id="updateLevelSection" class="form-section">
                <div class="form-section-header">
                    <h3>Update Country Status</h3>
                    <p>Change the color coding for a country on the map</p>
                </div>
                <form id="formUpdateLevel">
                    <div class="form-group">
                        <label for="updateLevelCountrySelect">Select Country</label>
                        <select id="updateLevelCountrySelect" required class="form-control">
                            <option value="">-- Choose Country --</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="updateLevelSelect">New Status / Level</label>
                        <select id="updateLevelSelect" required class="form-control">
                            <option value="L1">L1 - Established (Blue)</option>
                            <option value="L2">L2 - Growing (Light Green)</option>
                            <option value="L3">L3 - Developing (Yellow)</option>
                            <option value="L4">L4 - Emerging (Orange)</option>
                            <option value="inactive">Inactive (Grey)</option>
                            <option value="cancelled">Cancelled (Red)</option>
                            <option value="default">Default (Theme Orange)</option>
                        </select>
                    </div>
                    <div class="status-preview">
                        <span class="preview-label">Preview:</span>
                        <span id="statusPreviewColor" class="preview-color" style="background: #2196f3"></span>
                    </div>
                    <button type="submit" class="submit-btn">Update Map Color</button>
                </form>
            </div>

            <div id="editChurchSection" class="form-section">
                <div class="form-section-header">
                    <h3>Edit Church Details</h3>
                    <p>Update existing church metrics</p>
                </div>
                <form id="formEditChurch">
                    <div class="form-group">
                        <label for="editChurchCountrySelect">Select Country</label>
                        <select id="editChurchCountrySelect" required class="form-control">
                            <option value="">-- Choose Country --</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="editChurchSelect">Select Church</label>
                        <select id="editChurchSelect" required class="form-control">
                            <option value="">-- Choose Church --</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="editChurchYear">Year Started</label>
                            <input type="number" id="editChurchYear" placeholder="2024" min="1900" max="2100">
                        </div>
                        <div class="form-group">
                            <label for="editChurchAttendees">Attendees</label>
                            <input type="number" id="editChurchAttendees" placeholder="50" min="0">
                        </div>
                    </div>
                    <button type="submit" class="submit-btn">Update Church</button>
                </form>
            </div>

            <div id="editStaffSection" class="form-section">
                <div class="form-section-header">
                    <h3>Edit Staff Details</h3>
                    <p>Update staff information and discipleship progress</p>
                </div>
                <form id="formEditStaff">
                    <div class="form-group">
                        <label for="editStaffChurchSelect">Select Church</label>
                        <select id="editStaffChurchSelect" required class="form-control">
                            <option value="">-- Choose Church --</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="editStaffSelect">Select Staff Member</label>
                        <select id="editStaffSelect" required class="form-control">
                            <option value="">-- Choose Staff Member --</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="editStaffAge">Age</label>
                            <input type="number" id="editStaffAge" placeholder="30" min="18" max="120">
                        </div>
                        <div class="form-group">
                            <label for="editStaffYear">Year Joined</label>
                            <input type="number" id="editStaffYear" placeholder="2024" min="1900" max="2100">
                        </div>
                    </div>
                    <div class="discipleship-tracker">
                        <h4>Discipleship Progress Tracker</h4>
                        <div class="form-row discipleship-row">
                            <div class="form-group">
                                <label for="editStaffEvangelism">Evangelism</label>
                                <select id="editStaffEvangelism" class="form-control">
                                    <option value="None">None</option>
                                    <option value="Model">Model</option>
                                    <option value="Assist">Assist</option>
                                    <option value="Watch">Watch</option>
                                    <option value="Leader">Leader</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="editStaffSalvation">Salvation</label>
                                <select id="editStaffSalvation" class="form-control">
                                    <option value="None">None</option>
                                    <option value="Model">Model</option>
                                    <option value="Assist">Assist</option>
                                    <option value="Watch">Watch</option>
                                    <option value="Leader">Leader</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="editStaffBaptism">Baptism</label>
                                <select id="editStaffBaptism" class="form-control">
                                    <option value="None">None</option>
                                    <option value="Model">Model</option>
                                    <option value="Assist">Assist</option>
                                    <option value="Watch">Watch</option>
                                    <option value="Leader">Leader</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="submit-btn">Update Staff</button>
                </form>
            </div>
            
        </div>
    </div>

    <div id="sidebar" class="sidebar">
        <button id="closeSidebar" class="sidebar-close" title="Close" aria-label="Close sidebar">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
        <div id="sidebarContent"></div>
    </div>

    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-spinner">
            <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg" style="display:block;margin:0 auto 18px">
                <rect width="52" height="52" rx="10" fill="#db5729"/>
                <text x="26" y="38" text-anchor="middle" font-family="Raleway,sans-serif" font-weight="800" font-size="34" fill="white">D</text>
            </svg>
            <div class="spinner"></div>
            <p>Loading map data...</p>
        </div>
    </div>

    <div id="toastContainer" class="toast-container"></div>

    <?php
    return ob_get_clean(); 
}
add_shortcode('door_ministry_map', 'door_map_shortcode');


/**
 * 3. Add to Disciple.Tools Extensions Menu
 */
function add_door_map_to_dt_extensions() {
    add_submenu_page(
        'dt_extensions',                 
        'DOOR Ministry Map',             
        'DOOR Map',                      
        'manage_options',                
        'door-ministry-map',             
        'render_door_map_admin_page'     
    );
}
add_action('admin_menu', 'add_door_map_to_dt_extensions', 99);


/**
 * 4. Display the map on the new admin page
 */
function render_door_map_admin_page() {
    echo '<div class="wrap" style="margin-top: 20px;">';
    echo do_shortcode('[door_ministry_map]'); 
    echo '</div>';
}


/**
 * 5. Create a Custom Frontend Page for Disciple.Tools
 */
function door_map_frontend_endpoint() {
    if (strpos($_SERVER['REQUEST_URI'], '/ministry-map') !== false) {
        get_header(); 
        
        echo '<div style="width: 100%; height: calc(100vh - 50px);">';
        echo do_shortcode('[door_ministry_map]');
        echo '</div>';
        
        get_footer();
        exit;
    }
}
add_action('template_redirect', 'door_map_frontend_endpoint', 1);


/**
 * 6. Add "Global Map" to the Frontend Top Navigation (Dynamic Menu Fix)
 */
function door_map_add_nav_tab() {
    if (!is_admin()) {
        ?>
        <script>
            function injectMapTab() {
                if (document.getElementById("custom-dt-map-tab")) return;

                var links = document.querySelectorAll("a");
                var metricsLink = Array.from(links).find(link => link.textContent && link.textContent.includes("Metrics"));
                
                if (metricsLink && metricsLink.parentNode && metricsLink.parentNode.parentNode) {
                    var mapTab = document.createElement("li");
                    mapTab.id = "custom-dt-map-tab";
                    mapTab.className = metricsLink.parentNode.className; 
                    
                    mapTab.innerHTML = '<a href="/ministry-map/" style="display:flex; align-items:center; gap:5px;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg> Global Map</a>';
                    
                    metricsLink.parentNode.parentNode.appendChild(mapTab);
                }
            }

            var observer = new MutationObserver(function(mutations) {
                injectMapTab();
            });
            
            document.addEventListener("DOMContentLoaded", function() {
                observer.observe(document.body, { childList: true, subtree: true });
                injectMapTab();
            });
        </script>
        <?php
    }
}
add_action('wp_footer', 'door_map_add_nav_tab', 99);