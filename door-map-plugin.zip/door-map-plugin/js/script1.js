/* ═══════════════════════════════════════════════════════════════════════════
   DOOR International — Global Ministry Map
   Version 3.0.0  |  DiscipleTools API Integration (WordPress Optimized)

   Groups   (DT post_type: "groups")   → Churches on the map
   Contacts (DT post_type: "contacts") → Staff, filtered by faith_status = "staff"
   ═══════════════════════════════════════════════════════════════════════════ */
'use strict';

// ============================================================================
// 1. CONFIGURATION & GLOBAL VARIABLES
// ============================================================================

const CONFIG = {
    map: {
        initialView: [20, 0],
        initialZoom: 2,
        minZoom: 2,
        maxZoom: 12,
        maxBounds: [[-90, -180], [90, 180]]
    },
    sensitiveWindow: { latMin: 10, latMax: 40, lngMin: -10, lngMax: 145 },
    obfuscationDistance: 0.27   // ~15 km offset when obfuscation is on
};

const LEVEL_COLORS = {
    L1:        '#2196f3',
    L2:        '#8bc34a',
    L3:        '#ffeb3b',
    L4:        '#ff9800',
    inactive:  '#9e9e9e',
    cancelled: '#f44336',
    default:   '#db5729'
};

const DISC_LEVEL_ORDER  = ['milestone_model', 'milestone_assist', 'milestone_watch', 'milestone_leader'];
const DISC_LEVEL_LABELS = { milestone_model: 'Model', milestone_assist: 'Assist', milestone_watch: 'Watch', milestone_leader: 'Leader' };
const DISC_DISPLAY      = ['None', 'Model', 'Assist', 'Watch', 'Leader'];
const DT_STATUS_TO_LEVEL = { active: 'default', inactive: 'inactive' };

const GEOJSON_NAME_MAP = {
    'United States': 'United States of America',
    'Tanzania':      'United Republic of Tanzania'
};

// DT REST API — authenticated fetch wrapper (FIXED)
const DT_API = (() => {
    // Look for the specific data we passed from PHP
    const src = window.dtMapData || {};
    
    // Fallback to standard WordPress API settings if D.T data is missing
    const wpBase = (window.wpApiSettings && window.wpApiSettings.root) ? window.wpApiSettings.root : '/wp-json';
    const wpNonce = (window.wpApiSettings && window.wpApiSettings.nonce) ? window.wpApiSettings.nonce : '';

    const base  = (src.root  || wpBase).replace(/\/$/, '');
    const nonce = src.nonce  || wpNonce;
    
    const canCreateGroups   = src.canCreateGroups   !== 'false';
    const canCreateContacts = src.canCreateContacts !== 'false';
    
    return { base, nonce, canCreateGroups, canCreateContacts };
})();

// LIVE DATA STORE
const liveData = {
    countryStats:  {},   
    stateStats:    {},   
    churchDetails: {},   
    staffDetails:  {},   
    dtGroupIds:    {},   
    dtContactIds:  {}    
};

let countries = [];     

// Map & UI Globals (Initialized after DOM loads)
let map, lightTiles, darkTiles;
let churchMarkers, stateMarkers, countryMarkers, stateShapeMarkers;
let addChurchMapInstance = null;
let addChurchMarker = null;
let pinSecurityMode = 'normal';
let worldGeoJSON = null, usGeoJSON = null, indiaGeoJSON = null;
let currentCountry = null, currentStateChurches = null;


// ============================================================================
// 2. CORE FUNCTIONS & LOGIC
// ============================================================================

async function dtFetch(path, method = 'GET', body = null) {
    const res = await fetch(`${DT_API.base}${path}`, {
        method,
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': DT_API.nonce },
        credentials: 'same-origin',
        body: body ? JSON.stringify(body) : undefined
    });
    if (!res.ok) {
        const msg = await res.text().catch(() => res.statusText);
        throw new Error(`DT ${method} ${path} → ${res.status}: ${msg}`);
    }
    return res.json();
}

async function dtFetchAll(postType, query = {}) {
    const all = [];
    let page = 1;
    const perPage = 100;
    while (true) {
        const params = new URLSearchParams({ ...query, limit: perPage, offset: (page - 1) * perPage });
        const data = await dtFetch(`/dt-posts/v2/${postType}?${params}`);
        if (!data.posts?.length) break;
        all.push(...data.posts);
        if (all.length >= (data.total || all.length)) break;
        page++;
    }
    return all;
}

function highestDiscLabel(valueArray) {
    if (!valueArray?.length) return 'None';
    let maxIdx = -1;
    valueArray.forEach(v => {
        const i = DISC_LEVEL_ORDER.indexOf(v);
        if (i > maxIdx) maxIdx = i;
    });
    return maxIdx >= 0 ? DISC_LEVEL_LABELS[DISC_LEVEL_ORDER[maxIdx]] : 'None';
}

function discLabelToIndex(label) { return DISC_DISPLAY.indexOf(label); }

function discLabelToDTKeys(label) {
    const map = { Model: 'milestone_model', Assist: 'milestone_assist', Watch: 'milestone_watch', Leader: 'milestone_leader' };
    return map[label] ? [map[label]] : [];
}

function extractCoords(rec) {
    if (rec.location_grid_meta?.length) {
        const m = rec.location_grid_meta[0];
        if (m.lat && m.lng) return [parseFloat(m.lat), parseFloat(m.lng)];
    }
    if (rec.location_grid?.length) {
        const g = rec.location_grid[0];
        if (g.lat && g.lng) return [parseFloat(g.lat), parseFloat(g.lng)];
    }
    return null;
}

function extractCountry(rec) {
    const g = rec.location_grid?.[0];
    if (!g) return null;
    return g.country_name || g.admin0_label || g.label?.split(',').pop()?.trim() || null;
}

function extractRegion(rec) {
    const g = rec.location_grid?.[0];
    if (!g) return null;
    return g.admin1_label || g.label?.split(',')[0]?.trim() || g.label || null;
}

async function loadLiveData() {
    showToast('Loading live data from DiscipleTools…', 'info', 4000);
    try {
        const groups = await dtFetchAll('groups', {
            fields: 'name,group_status,group_type,start_date,member_count,location_grid,location_grid_meta,leaders,coaches,parent_groups,child_groups,door_map_level'
        });
        const staffContacts = await dtFetchAll('contacts', {
            fields: 'name,age_range,salvation,baptism,evangelism,coaches,groups,faith_status',
            'faith_status[]': 'staff'
        });

        const staffByGroupId = {};
        staffContacts.forEach(c => {
            liveData.dtContactIds[c.name] = c.ID;
            (c.groups || []).forEach(g => {
                (staffByGroupId[g.ID] = staffByGroupId[g.ID] || []).push(c);
            });
        });

        countries = [];
        const countryMap = {};
        const levelPriority = { L4:6, L3:5, L2:4, L1:3, default:2, inactive:1, cancelled:0 };

        groups.forEach(g => {
            const churchName  = g.name || `Group ${g.ID}`;
            const coords      = extractCoords(g);
            const countryName = extractCountry(g) || 'Unknown';
            const regionName  = extractRegion(g)  || 'Unknown';
            const level = g.door_map_level || DT_STATUS_TO_LEVEL[g.group_status] || 'default';

            liveData.dtGroupIds[churchName] = g.ID;
            const yearStarted = g.start_date?.timestamp ? new Date(g.start_date.timestamp * 1000).getFullYear() : null;
            const leaders      = (g.leaders || []).map(l => l.post_title || l.name || 'Unknown');
            const parentChurch = g.parent_groups?.length ? (g.parent_groups[0].post_title || g.parent_groups[0].name || null) : null;
            const siblingChurches = (g.child_groups || []).filter(c => c.ID !== g.ID).map(c => c.post_title || c.name || '');

            liveData.churchDetails[churchName] = { yearStarted, attendees: g.member_count || 0, leaders, parentChurch, siblingChurches };

            const staffList = (staffByGroupId[g.ID] || []).map(c => {
                const eLvl = highestDiscLabel(c.evangelism);
                const sLvl = highestDiscLabel(c.salvation);
                const bLvl = highestDiscLabel(c.baptism);
                const maxIdx = Math.max(discLabelToIndex(eLvl), discLabelToIndex(sLvl), discLabelToIndex(bLvl));
                const mentoredBy = c.coaches?.length ? (c.coaches[0].post_title || c.coaches[0].name || null) : null;
                return { name: c.name, yearJoined: null, age: c.age_range || null, mentoredBy, mentoring: [], discipleship: { evangelism: eLvl, salvation: sLvl, baptism: bLvl }, discipleshipLevel: Math.max(1, maxIdx) };
            });

            staffList.forEach(s => {
                if (s.mentoredBy) {
                    const mentor = staffList.find(m => m.name === s.mentoredBy);
                    if (mentor && !mentor.mentoring.includes(s.name)) mentor.mentoring.push(s.name);
                }
            });

            liveData.staffDetails[churchName] = staffList;

            if (!liveData.countryStats[countryName]) liveData.countryStats[countryName] = { churches:0, groups:0, staff:0, volunteers:0 };
            liveData.countryStats[countryName].churches++;
            liveData.countryStats[countryName].groups++;
            liveData.countryStats[countryName].staff += staffList.length;

            if (!liveData.stateStats[countryName]) liveData.stateStats[countryName] = {};
            if (!liveData.stateStats[countryName][regionName]) {
                liveData.stateStats[countryName][regionName] = { coords: coords || [0,0], churches:0, groups:0, staff:0, names:[] };
            }
            liveData.stateStats[countryName][regionName].churches++;
            liveData.stateStats[countryName][regionName].staff += staffList.length;
            liveData.stateStats[countryName][regionName].names.push(churchName);

            if (!countryMap[countryName]) {
                countryMap[countryName] = { name: countryName, coords: coords || [0,0], countryCode: '', level, sensitive: coords ? isIn1040Window(coords) : false, churches: [] };
                countries.push(countryMap[countryName]);
            }

            if ((levelPriority[level] || 0) > (levelPriority[countryMap[countryName].level] || 0)) {
                countryMap[countryName].level = level;
            }

            if (coords) countryMap[countryName].churches.push({ name: churchName, coords });
        });

        renderGlobalDashboard();
        showAllCountries();

        const overlay = document.getElementById('loadingOverlay');
        if (overlay) { overlay.classList.add('hidden'); setTimeout(() => overlay.remove(), 500); }
        showToast(`Loaded ${groups.length} churches, ${staffContacts.length} staff`, 'success');

    } catch (err) {
        console.error('DT API load error:', err);
        showToast('Could not load live data — check connection and permissions', 'error', 7000);
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) { overlay.classList.add('hidden'); setTimeout(() => overlay.remove(), 500); }
        renderGlobalDashboard();
        showAllCountries();
    }
}

function isIn1040Window(coords) {
    const [lat, lng] = coords;
    const { latMin, latMax, lngMin, lngMax } = CONFIG.sensitiveWindow;
    return lat >= latMin && lat <= latMax && lng >= lngMin && lng <= lngMax;
}

function hashString(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
}

function getObfuscatedCoords(church) {
    const h = hashString(church.name);
    const off = CONFIG.obfuscationDistance;
    return [ church.coords[0] + ((h & 0xFF) / 255 - 0.5) * off, church.coords[1] + (((h >> 8) & 0xFF) / 255 - 0.5) * off ];
}

function resolveCoords(church) {
    if (!isIn1040Window(church.coords)) return church.coords;
    if (pinSecurityMode === 'hidden')    return null;
    if (pinSecurityMode === 'obfuscate') return getObfuscatedCoords(church);
    return church.coords;
}

function escapeHtml(text) {
    if (text == null) return '';
    const d = document.createElement('div');
    d.textContent = String(text);
    return d.innerHTML;
}

function getChurchLocationData(churchName) {
    for (const country of countries) {
        if (country.churches.find(ch => ch.name === churchName)) {
            let stateName = 'Unknown';
            const states = liveData.stateStats[country.name];
            if (states) {
                for (const [sName, sData] of Object.entries(states)) {
                    if (sData.names.includes(churchName)) { stateName = sName; break; }
                }
            }
            return { country: country.name, state: stateName };
        }
    }
    return { country: null, state: null };
}

function showToast(msg, type = 'info', duration = 3000) {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = msg;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
}

function initMap() {
    map = L.map('map', {
        minZoom: CONFIG.map.minZoom,
        maxZoom: CONFIG.map.maxZoom,
        zoom:    CONFIG.map.initialZoom,
        dragging: true,
        scrollWheelZoom: true,
        zoomControl: true
    }).setView(CONFIG.map.initialView, CONFIG.map.initialZoom);

    map.setMaxBounds(CONFIG.map.maxBounds);

    lightTiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, attribution: '© OpenStreetMap contributors', noWrap: true
    });

    darkTiles = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19, attribution: '© OpenStreetMap, © CartoDB', noWrap: true
    });

    L.control.scale({ position: 'bottomleft' }).addTo(map);

    churchMarkers    = L.layerGroup().addTo(map);
    stateMarkers     = L.layerGroup().addTo(map);
    countryMarkers   = L.layerGroup().addTo(map);
    stateShapeMarkers = L.layerGroup().addTo(map);

    map.on('click', () => { closeSidebar(); showAllCountries(); });

    // Load GeoJSONs
    fetch('https://raw.githubusercontent.com/johan/world.geo.json/master/countries.geo.json')
        .then(r => r.json()).then(d => { worldGeoJSON = d; showAllCountries(); })
        .catch(err => console.error('World borders load error:', err));

    fetch('https://raw.githubusercontent.com/PublicaMundi/MappingAPI/master/data/geojson/us-states.json')
        .then(r => r.json()).then(d => usGeoJSON = d)
        .catch(err => console.error('US states load error:', err));

    fetch('https://raw.githubusercontent.com/geohacker/india/master/state/india_state.geojson')
        .then(r => r.json()).then(d => indiaGeoJSON = d)
        .catch(() => fetch('https://gist.githubusercontent.com/shantanuo/91c13bf8fb851eec70d0/raw/india_state.geojson').then(r => r.json()).then(d => indiaGeoJSON = d));
}

function applyTheme(mode) {
    document.documentElement.setAttribute('data-theme', mode);
    localStorage.setItem('theme', mode);
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    
    if (themeToggleBtn) {
        const text    = themeToggleBtn.querySelector('.btn-text');
        const iconWrap = themeToggleBtn.querySelector('.btn-icon .icon');
        if (text) text.textContent = mode === 'dark' ? 'Light Mode' : 'Dark Mode';
        if (iconWrap) {
            iconWrap.innerHTML = mode === 'dark'
                ? '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>'
                : '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
        }
    }

    if (map) {
        if (mode === 'dark') {
            if (map.hasLayer(lightTiles)) map.removeLayer(lightTiles);
            darkTiles.addTo(map);
        } else {
            if (map.hasLayer(darkTiles)) map.removeLayer(darkTiles);
            lightTiles.addTo(map);
        }
    }

    if (addChurchMapInstance) {
        addChurchMapInstance.eachLayer(l => { if (l instanceof L.TileLayer) addChurchMapInstance.removeLayer(l); });
        L.tileLayer(mode === 'dark'
            ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
            : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            { attribution: '© OpenStreetMap' }
        ).addTo(addChurchMapInstance);
    }
}

function initTheme() { applyTheme(localStorage.getItem('theme') || 'light'); }

function createDotIcon(isSensitive = false, size = 'normal') {
    const sizes = { small:10, normal:14, large:20, country:24 };
    const d = sizes[size] || 14;
    const bg = isSensitive ? 'linear-gradient(135deg,#db5729 0%,#ff9800 100%)' : '#db5729';
    const pulse = isSensitive ? 'pulse-sensitive' : '';
    return L.divIcon({
        html: `<div class="marker-dot ${pulse}" style="background:${bg};width:${d}px;height:${d}px;border-radius:50%;border:2px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);"></div>`,
        iconSize: [d, d], iconAnchor: [d/2, d/2], className: 'custom-dot'
    });
}

function openSidebar(html) {
    const sidebar = document.getElementById('sidebar');
    const sidebarContent = document.getElementById('sidebarContent');
    if(!sidebar || !sidebarContent) return;
    
    sidebarContent.innerHTML = html;
    sidebar.classList.add('open');
    setupToggles(sidebarContent);
}

function closeSidebar() { 
    const sidebar = document.getElementById('sidebar');
    if(sidebar) sidebar.classList.remove('open'); 
}

function setupToggles(container) {
    if (!container) return;
    container.querySelectorAll('.toggle-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const el = container.querySelector('#' + btn.dataset.target);
            if (!el) return;
            const hidden = el.style.display === 'none';
            el.style.display = hidden ? 'block' : 'none';
            btn.textContent = (hidden ? '▼ ' : '▶ ') + btn.dataset.label;
        });
    });
}

function generateChurchDetailsHTML(churchName, uid, expanded = false, showHeader = true) {
    uid = String(uid).replace(/[^a-zA-Z0-9_-]/g, '');  
    const details = liveData.churchDetails[churchName] || {};
    const staff   = liveData.staffDetails[churchName]  || [];
    const expStyle = expanded ? 'block' : 'none';
    const icon = expanded ? '▼' : '▶';

    let html = `<div class="church-accordion" style="margin-top:8px;">`;
    if (showHeader) {
        html += `<button class="toggle-btn main-church-toggle" data-target="church-wrap-${uid}" data-label="${escapeHtml(churchName)}">${icon} ${escapeHtml(churchName)}</button>`;
    }
    html += `<div id="church-wrap-${uid}" class="toggle-content" style="display:${showHeader ? expStyle : 'block'};">
        <button class="toggle-btn" data-target="cinfo-${uid}" data-label="Church Info">▼ Church Info</button>
        <div id="cinfo-${uid}" class="toggle-content" style="display:block;">`;

    if (details.yearStarted)           html += `<p><span class="label">Year started</span><span class="value">${details.yearStarted}</span></p>`;
    if (details.attendees)             html += `<p><span class="label">Attendees</span><span class="value">${details.attendees}</span></p>`;
    if (details.leaders?.length)       html += `<p><span class="label">Leaders</span><span class="value">${escapeHtml(details.leaders.join(', '))}</span></p>`;
    if (details.parentChurch)          html += `<p><span class="label">Parent church</span><span class="value">${escapeHtml(details.parentChurch)}</span></p>`;
    if (details.siblingChurches?.length) html += `<p><span class="label">Child churches</span><span class="value">${escapeHtml(details.siblingChurches.join(', '))}</span></p>`;
    if (!details.yearStarted && !details.attendees) html += `<p class="no-data">No details on record yet.</p>`;

    html += `</div>`;
    html += `<button class="toggle-btn" data-target="sinfo-${uid}" data-label="Staff (${staff.length})">▼ Staff (${staff.length})</button>
             <div id="sinfo-${uid}" class="toggle-content" style="display:block;">`;

    if (staff.length) {
        const SAFE_DISC_VALS = ['none','model','assist','watch','leader'];
        const safeDisc = v => SAFE_DISC_VALS.includes(v?.toLowerCase()) ? v.toLowerCase() : 'none';
        staff.forEach(s => {
            const pct = Math.round(((s.discipleshipLevel || 1) / 4) * 100);
            const discHtml = s.discipleship ? `
                <div class="disc-milestones">
                    <span class="dm-badge dm-${safeDisc(s.discipleship.evangelism)}">Evangelism: ${escapeHtml(s.discipleship.evangelism)}</span>
                    <span class="dm-badge dm-${safeDisc(s.discipleship.salvation)}">Salvation: ${escapeHtml(s.discipleship.salvation)}</span>
                    <span class="dm-badge dm-${safeDisc(s.discipleship.baptism)}">Baptism: ${escapeHtml(s.discipleship.baptism)}</span>
                </div>` : '';

            html += `<div class="staff-card">
                <p class="staff-name">${escapeHtml(s.name)}</p>
                ${s.yearJoined ? `<p><span class="label">Year joined</span><span class="value">${s.yearJoined}</span></p>` : ''}
                ${s.age        ? `<p><span class="label">Age range</span><span class="value">${escapeHtml(s.age)}</span></p>`   : ''}
                <p><span class="label">Mentored by</span><span class="value">${escapeHtml(s.mentoredBy || 'None')}</span></p>
                ${s.mentoring?.length ? `<p><span class="label">Mentoring</span><span class="value">${escapeHtml(s.mentoring.join(', '))}</span></p>` : ''}
                ${discHtml}
                <p><span class="label">Overall level</span>
                  <span class="value disc-bar-wrap">
                    <span class="disc-bar" style="width:${pct}%"></span>
                    <span class="disc-label">${s.discipleshipLevel || 1}/4</span>
                  </span></p>
            </div>`;
        });
    } else {
        html += `<p class="no-data">No staff on record yet.</p>`;
    }
    html += `</div></div></div>`;
    return html;
}

function buildChurchSidebar(church) {
    const sensitive = isIn1040Window(church.coords);
    let notice = '';
    if (sensitive && pinSecurityMode === 'obfuscate') notice = `<div class="obscure-notice">Pin location is approximate for security (10/40 Window)</div>`;
    if (sensitive && pinSecurityMode === 'hidden')    notice = `<div class="obscure-notice">10/40 Window church — pin hidden on map</div>`;
    return `<div class="sb-header"><h2>${escapeHtml(church.name)}</h2></div>${notice}<hr>` + generateChurchDetailsHTML(church.name, 'direct-pin', true, false);
}

function buildCountrySidebar(country) {
    const stats  = liveData.countryStats[country.name] || { churches:0, groups:0, staff:0, volunteers:0 };
    const states = liveData.stateStats[country.name];
    let html = `<div class="sb-header"><h2>${escapeHtml(country.name)}</h2></div><hr>
        <div class="stat-grid">
          <div class="stat-cell"><span class="stat-num">${stats.churches}</span><span class="stat-lbl">Churches</span></div>
          <div class="stat-cell"><span class="stat-num">${stats.groups}</span><span class="stat-lbl">Groups</span></div>
          <div class="stat-cell"><span class="stat-num">${stats.staff}</span><span class="stat-lbl">Staff</span></div>
          <div class="stat-cell"><span class="stat-num">${stats.volunteers || 0}</span><span class="stat-lbl">Volunteers</span></div>
        </div>`;

    if (states && Object.keys(states).length) {
        html += `<hr><h3 style="margin-top:15px;margin-bottom:10px;font-size:1.05em;color:var(--gray-800);">Regional Breakdown</h3><ul class="state-list">`;
        for (const [name, data] of Object.entries(states)) {
            html += `<li style="margin-bottom:15px;"><strong>${escapeHtml(name)}</strong><span style="display:block;margin-bottom:8px;">${data.churches} churches · ${data.groups || 0} groups · ${data.staff} staff</span>`;
            data.names.forEach((cName, idx) => {
                html += generateChurchDetailsHTML(cName, `country-${name.replace(/[^a-zA-Z0-9]/g,'').toLowerCase()}-${idx}`, false, true);
            });
            html += `</li>`;
        }
        html += `</ul>`;
    } else {
        html += `<hr><h3 style="margin-top:15px;margin-bottom:10px;font-size:1.05em;color:var(--gray-800);">Churches</h3>`;
        country.churches.forEach((ch, idx) => { html += generateChurchDetailsHTML(ch.name, `country-direct-${idx}`, false, true); });
    }
    return html;
}

function buildStateSidebar(stateName, stateData) {
    let html = `<div class="sb-header"><h2>${escapeHtml(stateName)}</h2></div><hr>`;
    if (stateData) {
        html += `<div class="stat-grid">
          <div class="stat-cell"><span class="stat-num">${stateData.churches}</span><span class="stat-lbl">Churches</span></div>
          <div class="stat-cell"><span class="stat-num">${stateData.groups || 0}</span><span class="stat-lbl">Groups</span></div>
          <div class="stat-cell"><span class="stat-num">${stateData.staff}</span><span class="stat-lbl">Staff</span></div>
        </div>
        <hr><h3 style="margin-top:15px;margin-bottom:10px;font-size:1.05em;color:var(--gray-800);">Churches in ${escapeHtml(stateName)}</h3>`;
        stateData.names.forEach((cName, idx) => { html += generateChurchDetailsHTML(cName, `state-${idx}`, false, true); });
    } else {
        html += `<p class="no-data">No active ministries in this region yet.</p>`;
    }
    return html;
}

function renderSpecificChurchPins(list) {
    churchMarkers.clearLayers();
    if (!list) return;
    list.forEach(ch => {
        const pos = resolveCoords(ch);
        if (!pos) return;
        const marker = L.marker(pos, { icon: createDotIcon(isIn1040Window(ch.coords), 'normal'), title: ch.name });
        marker.on('click', e => { L.DomEvent.stopPropagation(e); openSidebar(buildChurchSidebar(ch)); });
        marker.addTo(churchMarkers);
    });
}

function renderStateShapes(geoJsonData, countryData) {
    L.geoJSON(geoJsonData, {
        style: () => ({ color:'#2e7d32', weight:2, fillColor:'#2e7d32', fillOpacity:0.35, className:'state-shape' }),
        onEachFeature: (feature, layer) => {
            layer.on('mouseover', function() { this.setStyle({ fillOpacity:0.65 }); });
            layer.on('mouseout',  function() { this.setStyle({ fillOpacity:0.35 }); });
            layer.on('click', e => {
                L.DomEvent.stopPropagation(e);
                map.setMaxZoom(12);
                map.fitBounds(layer.getBounds(), { padding:[30,30], animate:true });
                stateShapeMarkers.clearLayers();

                const stateName = feature.properties.name || feature.properties.NAME_1 || feature.properties.st_nm || 'Unknown';
                const stateStats = liveData.stateStats[countryData.name];
                let matchedData = null, matchedName = null;

                if (stateStats) {
                    for (const [sName, sData] of Object.entries(stateStats)) {
                        if (stateName.toLowerCase().includes(sName.toLowerCase()) || sName.toLowerCase().includes(stateName.toLowerCase())) {
                            matchedData = sData; matchedName = sName; break;
                        }
                    }
                }
                const toRender = matchedData?.names ? countryData.churches.filter(c => matchedData.names.includes(c.name)) : [];
                currentStateChurches = toRender;
                renderSpecificChurchPins(toRender);
                openSidebar(buildStateSidebar(matchedName || stateName, matchedData));
            });
        }
    }).addTo(stateShapeMarkers);
}

function showAllCountries() {
    map.setMaxZoom(2);
    map.setView(CONFIG.map.initialView, CONFIG.map.initialZoom);
    currentCountry = null; currentStateChurches = null;
    countryMarkers.clearLayers(); churchMarkers.clearLayers();
    stateMarkers.clearLayers();   stateShapeMarkers.clearLayers();

    if (!worldGeoJSON) return;

    const active = {};
    countries.forEach(c => {
        if (pinSecurityMode === 'hidden' && c.churches.every(ch => isIn1040Window(ch.coords))) return;
        active[GEOJSON_NAME_MAP[c.name] || c.name] = c;
    });

    L.geoJSON(worldGeoJSON, {
        filter: f => !!active[f.properties.name],
        style: f => {
            const c = active[f.properties.name];
            const col = LEVEL_COLORS[c.level] || LEVEL_COLORS.default;
            return { color: col, weight:2, fillColor: col, fillOpacity:0.45, className:'country-shape' };
        },
        onEachFeature: (feature, layer) => {
            const cData = active[feature.properties.name];
            layer.on('mouseover', function() { this.setStyle({ fillOpacity:0.75, weight:3 }); });
            layer.on('mouseout',  function() { this.setStyle({ fillOpacity:0.45, weight:2 }); });
            layer.on('click', e => {
                L.DomEvent.stopPropagation(e);
                map.setMaxZoom(8);
                countryMarkers.clearLayers();
                map.fitBounds(layer.getBounds(), { padding:[20,20], animate:true });
                currentCountry = cData;

                if (cData.name === 'United States' && usGeoJSON) {
                    renderStateShapes(usGeoJSON, cData);
                } else if (cData.name === 'India' && indiaGeoJSON) {
                    renderStateShapes(indiaGeoJSON, cData);
                } else {
                    renderSpecificChurchPins(cData.churches);
                    stateMarkers.clearLayers();
                    const states = liveData.stateStats[cData.name];
                    if (states) {
                        Object.entries(states).forEach(([name, data]) => {
                            const m = L.marker(data.coords || cData.coords, { icon: createDotIcon(cData.sensitive||false, 'normal'), title: name });
                            m.bindPopup(`<strong>${escapeHtml(name)}</strong><br>${data.churches} churches · ${data.groups||0} groups · ${data.staff} staff`);
                            m.addTo(stateMarkers);
                        });
                    }
                    openSidebar(buildCountrySidebar(cData));
                }
            });
        }
    }).addTo(countryMarkers);
}

function applySecurityMode(mode) {
    pinSecurityMode = (pinSecurityMode === mode) ? 'normal' : mode;
    const securityOpts  = document.querySelectorAll('.sec-option');
    const securityBtn   = document.getElementById('obscurePinsBtn');
    const securityPopup = document.getElementById('securityPopup');

    securityOpts.forEach(o => o.classList.toggle('selected', o.dataset.mode === pinSecurityMode));
    
    if(securityBtn) {
        const text = securityBtn.querySelector('.btn-text');
        if (text) text.textContent = { normal:'Security: Off', obfuscate:'Security: Obfuscated', hidden:'Security: Hidden' }[pinSecurityMode];
        securityBtn.classList.remove('active');
    }
    if(securityPopup) securityPopup.classList.remove('open'); 

    if (currentStateChurches)      renderSpecificChurchPins(currentStateChurches);
    else if (currentCountry)        renderSpecificChurchPins(currentCountry.churches);
    else                            showAllCountries();
}

function populateFormDropdowns() {
    const ids = ['churchCountrySelect','staffChurchSelect','updateLevelCountrySelect','editChurchCountrySelect','editStaffChurchSelect'];
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.innerHTML = '<option value="">-- Choose --</option>';
    });

    countries.forEach(c => {
        ['churchCountrySelect','updateLevelCountrySelect','editChurchCountrySelect'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.innerHTML += `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`;
        });
        c.churches.forEach(ch => {
            ['staffChurchSelect','editStaffChurchSelect'].forEach(id => {
                const el = document.getElementById(id);
                if (el) el.innerHTML += `<option value="${escapeHtml(ch.name)}">${escapeHtml(ch.name)} (${escapeHtml(c.name)})</option>`;
            });
        });
    });
}

function initAddChurchMap() {
    if (!addChurchMapInstance) {
        addChurchMapInstance = L.map('addChurchMap', { minZoom:1, maxZoom:16, zoom:2 }).setView([20,0], 2);
        const mode = document.documentElement.getAttribute('data-theme');
        L.tileLayer(mode === 'dark'
            ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
            : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            { attribution: '© OpenStreetMap' }
        ).addTo(addChurchMapInstance);

        addChurchMapInstance.on('click', e => {
            const { lat, lng } = e.latlng;
            document.getElementById('addChurchLat').value = lat;
            document.getElementById('addChurchLng').value = lng;
            const ct = document.getElementById('selectedCoordsText');
            ct.textContent = `Location set — Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}`;
            ct.style.color = '#4caf50';
            if (addChurchMarker) addChurchMarker.setLatLng(e.latlng);
            else addChurchMarker = L.marker(e.latlng).addTo(addChurchMapInstance);
        });
    } else {
        setTimeout(() => addChurchMapInstance.invalidateSize(), 100);
    }
}

function setSaving(btn, saving, defaultText) {
    if(!btn) return;
    btn.disabled = saving;
    btn.textContent = saving ? 'Saving…' : defaultText;
}

function renderGlobalDashboard() {
    const active = countries.filter(c => !['inactive','cancelled'].includes(c.level));
    
    const elTotalCountries = document.getElementById('totalCountries');
    const elCountryList = document.getElementById('countryList');
    const elTotalChurches = document.getElementById('totalChurches');
    const elTotalGroups = document.getElementById('totalGroups');
    const elTotalStaff = document.getElementById('totalStaff');
    const elTotalVolunteers = document.getElementById('totalVolunteers');

    if(elTotalCountries) elTotalCountries.textContent = active.length;
    if(elCountryList) elCountryList.innerHTML = active.map(c => `<li>${escapeHtml(c.name)}</li>`).join('');

    let tC=0, tG=0, tS=0, tV=0;
    Object.values(liveData.countryStats).forEach(s => { tC += s.churches||0; tG += s.groups||0; tS += s.staff||0; tV += s.volunteers||0; });

    if(elTotalChurches) elTotalChurches.textContent  = tC;
    if(elTotalGroups) elTotalGroups.textContent    = tG;
    if(elTotalStaff) elTotalStaff.textContent     = tS;
    if(elTotalVolunteers) elTotalVolunteers.textContent = tV;
}

// ============================================================================
// 3. EVENT LISTENER SETUP
// ============================================================================

function setupEventListeners() {
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', e => {
            e.stopPropagation();
            applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
        });
    }

    const overviewModal = document.getElementById('globalOverviewModal');
    const btnOverview = document.getElementById('globalOverviewBtn');
    if(btnOverview) {
        btnOverview.onclick = e => {
            e.stopPropagation(); renderGlobalDashboard(); 
            if(overviewModal) overviewModal.style.display = 'block';
        };
    }

    const btnCloseOverview = document.getElementById('closeOverview');
    if(btnCloseOverview) {
        btnCloseOverview.onclick = () => { if(overviewModal) overviewModal.style.display = 'none'; };
    }

    const securityBtn   = document.getElementById('obscurePinsBtn');
    const securityPopup = document.getElementById('securityPopup');
    const securityOpts  = securityPopup ? securityPopup.querySelectorAll('.sec-option') : [];

    if(securityBtn && securityPopup) {
        securityBtn.onclick = e => {
            e.stopPropagation();
            const opening = !securityPopup.classList.contains('open');
            securityPopup.classList.toggle('open', opening);
            securityBtn.classList.toggle('active', opening);
        };
    }

    document.addEventListener('click', e => {
        if (securityPopup && securityBtn && !securityPopup.contains(e.target) && e.target !== securityBtn) {
            securityPopup.classList.remove('open'); securityBtn.classList.remove('active');
        }
        if (overviewModal && e.target === overviewModal) overviewModal.style.display = 'none';
    });

    securityOpts.forEach(opt => { 
        opt.onclick = e => { e.stopPropagation(); applySecurityMode(opt.dataset.mode); }; 
    });

    const btnCloseSidebar = document.getElementById('closeSidebar');
    if(btnCloseSidebar) {
        btnCloseSidebar.addEventListener('click', () => { closeSidebar(); showAllCountries(); });
    }

    const formsPage    = document.getElementById('formsPage');
    const formCards    = document.querySelectorAll('.form-card');
    const formSections = document.querySelectorAll('.form-section');

    const btnAddData = document.getElementById('addDataBtn');
    if(btnAddData) {
        btnAddData.onclick = () => {
            populateFormDropdowns();
            if(formsPage) formsPage.style.display = 'block';
            if (!addChurchMapInstance) initAddChurchMap();
        };
    }

    const btnCloseForms = document.getElementById('closeFormsPage');
    if(btnCloseForms) {
        btnCloseForms.onclick = () => { 
            if(formsPage) formsPage.style.display = 'none'; 
            showAllCountries(); 
        };
    }

    formCards.forEach(card => {
        card.onclick = () => {
            formCards.forEach(c => c.classList.remove('active'));
            formSections.forEach(s => s.classList.remove('active'));
            card.classList.add('active');
            const target = document.getElementById(card.dataset.target);
            if(target) target.classList.add('active');
            if (card.dataset.target === 'addChurchSection') setTimeout(() => addChurchMapInstance?.invalidateSize(), 50);
        };
    });

    const churchCountrySelect = document.getElementById('churchCountrySelect');
    if(churchCountrySelect) {
        churchCountrySelect.addEventListener('change', function() {
            const cName = this.value;
            if (!cName || !worldGeoJSON || !addChurchMapInstance) return;
            const feature = worldGeoJSON.features.find(f => f.properties.name.toLowerCase() === (GEOJSON_NAME_MAP[cName] || cName).toLowerCase());
            if (feature) addChurchMapInstance.fitBounds(L.geoJSON(feature).getBounds(), { padding:[20,20] });
            else {
                const cObj = countries.find(c => c.name === cName);
                if (cObj) addChurchMapInstance.setView(cObj.coords, 5);
            }
        });
    }

    // Form Submissions
    const formAddCountry = document.getElementById('formAddCountry');
    if(formAddCountry) {
        formAddCountry.addEventListener('submit', function(e) {
            e.preventDefault();
            const cName = document.getElementById('addCountryName').value.trim();
            const cCode = document.getElementById('addCountryCode').value.trim().toLowerCase();
            if (!worldGeoJSON) { showToast('Map data still loading — please wait', 'warning'); return; }
            const feature = worldGeoJSON.features.find(f => f.properties.name.toLowerCase() === (GEOJSON_NAME_MAP[cName] || cName).toLowerCase());
            if (!feature) { showToast(`Could not find borders for "${cName}". Check spelling.`, 'error'); return; }
            if (!countries.find(c => c.name.toLowerCase() === cName.toLowerCase())) {
                const center = L.geoJSON(feature).getBounds().getCenter();
                countries.push({ name: cName, coords: [center.lat, center.lng], countryCode: cCode, level: 'default', churches: [], sensitive: false });
                liveData.countryStats[cName] = { churches:0, groups:0, staff:0, volunteers:0 };
                liveData.stateStats[cName]   = {};
                showToast(`Added country: ${cName}`, 'success');
                showAllCountries();
            } else {
                showToast(`${cName} already exists`, 'warning');
            }
            this.reset(); populateFormDropdowns();
        });
    }

    const formAddChurch = document.getElementById('formAddChurch');
    if(formAddChurch) {
        formAddChurch.addEventListener('submit', async function(e) {
            e.preventDefault();
            const lat = document.getElementById('addChurchLat').value;
            const lng = document.getElementById('addChurchLng').value;
            if (!lat || !lng) { showToast('Click the mini-map to place a pin first', 'warning'); return; }
            const cName    = document.getElementById('churchCountrySelect').value;
            const sName    = document.getElementById('addChurchState').value.trim();
            const chName   = document.getElementById('addChurchName').value.trim();
            const year     = document.getElementById('addChurchYear').value;
            const attendees = document.getElementById('addChurchAttendees').value;
            const countryObj = countries.find(c => c.name === cName);
            if (!countryObj) { showToast('Country not found', 'error'); return; }
            const btn = this.querySelector('.submit-btn');
            setSaving(btn, true, 'Add Church');
            try {
                const payload = {
                    title: chName, group_status: 'active', group_type: 'church',
                    member_count: attendees ? parseInt(attendees) : 0,
                    location_grid_meta: [{ grid_meta_id: null, lat: String(lat), lng: String(lng), level: 'place', label: `${sName}, ${cName}` }]
                };
                if (year) payload.start_date = `${year}-01-01`;
                const created = await dtFetch('/dt-posts/v2/groups', 'POST', payload);
                const coords = [parseFloat(lat), parseFloat(lng)];
                countryObj.churches.push({ name: chName, coords });
                liveData.churchDetails[chName]  = { yearStarted: year || null, attendees: attendees || 0, leaders: [], parentChurch: null, siblingChurches: [] };
                liveData.staffDetails[chName]   = [];
                liveData.dtGroupIds[chName]     = created.ID;
                liveData.countryStats[cName].churches++;
                liveData.countryStats[cName].groups++;
                if (!liveData.stateStats[cName]) liveData.stateStats[cName] = {};
                if (!liveData.stateStats[cName][sName]) liveData.stateStats[cName][sName] = { coords, churches:0, groups:0, staff:0, names:[] };
                liveData.stateStats[cName][sName].churches++;
                liveData.stateStats[cName][sName].names.push(chName);
                showToast(`Church "${chName}" created in DiscipleTools`, 'success');
                this.reset();
                const ct = document.getElementById('selectedCoordsText');
                if(ct) {
                    ct.textContent = 'No location selected yet — click the map to place a pin.';
                    ct.style.color = '';
                }
                if (addChurchMarker) { addChurchMapInstance.removeLayer(addChurchMarker); addChurchMarker = null; }
                document.getElementById('addChurchLat').value = '';
                document.getElementById('addChurchLng').value = '';
                populateFormDropdowns();
            } catch (err) {
                console.error(err);
                showToast('Failed to save church — see console', 'error');
            } finally { setSaving(btn, false, 'Add Church'); }
        });
    }

    const formAddStaff = document.getElementById('formAddStaff');
    if(formAddStaff) {
        formAddStaff.addEventListener('submit', async function(e) {
            e.preventDefault();
            const chName    = document.getElementById('staffChurchSelect').value;
            const staffName = document.getElementById('addStaffName').value.trim();
            const age       = document.getElementById('addStaffAge').value;
            const eLvl      = document.getElementById('addStaffEvangelism').value;
            const sLvl      = document.getElementById('addStaffSalvation').value;
            const bLvl      = document.getElementById('addStaffBaptism').value;
            const groupId   = liveData.dtGroupIds[chName];
            const maxIdx = Math.max(discLabelToIndex(eLvl), discLabelToIndex(sLvl), discLabelToIndex(bLvl));
            const btn = this.querySelector('.submit-btn');
            setSaving(btn, true, 'Add Staff Member');
            try {
                const payload = {
                    title: staffName, faith_status: 'staff',
                    evangelism: { values: discLabelToDTKeys(eLvl).map(k => ({ value: k })) },
                    salvation:  { values: discLabelToDTKeys(sLvl).map(k => ({ value: k })) },
                    baptism:    { values: discLabelToDTKeys(bLvl).map(k => ({ value: k })) }
                };
                if (age) payload.age_range = age;
                if (groupId) payload.groups = { values: [{ value: groupId }] };
                const created = await dtFetch('/dt-posts/v2/contacts', 'POST', payload);
                if (!liveData.staffDetails[chName]) liveData.staffDetails[chName] = [];
                liveData.staffDetails[chName].push({
                    name: staffName, yearJoined: null, age: age || null,
                    mentoredBy: null, mentoring: [],
                    discipleship: { evangelism: eLvl, salvation: sLvl, baptism: bLvl },
                    discipleshipLevel: Math.max(1, maxIdx)
                });
                liveData.dtContactIds[staffName] = created.ID;
                const loc = getChurchLocationData(chName);
                if (loc.country && liveData.countryStats[loc.country]) liveData.countryStats[loc.country].staff++;
                showToast(`Staff member "${staffName}" created in DiscipleTools`, 'success');
                this.reset();
            } catch (err) {
                console.error(err);
                showToast('Failed to save staff member — see console', 'error');
            } finally { setSaving(btn, false, 'Add Staff Member'); }
        });
    }

    const formUpdateLevel = document.getElementById('formUpdateLevel');
    if(formUpdateLevel) {
        formUpdateLevel.addEventListener('submit', async function(e) {
            e.preventDefault();
            const cName      = document.getElementById('updateLevelCountrySelect').value;
            const newLvl     = document.getElementById('updateLevelSelect').value;
            const countryObj = countries.find(c => c.name === cName);
            if (!countryObj) { showToast('Country not found', 'error'); return; }
            const btn = this.querySelector('.submit-btn');
            setSaving(btn, true, 'Update Map Color');
            countryObj.level = newLvl;
            try {
                await Promise.all(
                    countryObj.churches.map(ch => {
                        const gId = liveData.dtGroupIds[ch.name];
                        return gId ? dtFetch(`/dt-posts/v2/groups/${gId}`, 'PATCH', { door_map_level: newLvl }).catch(err => console.warn(err)) : Promise.resolve();
                    })
                );
                showToast(`Updated ${cName} status to ${newLvl}`, 'success');
            } catch (err) {
                showToast('Some updates may have failed — check console', 'warning');
            } finally { setSaving(btn, false, 'Update Map Color'); }
            showAllCountries();
            this.reset();
        });
    }

    const editChurchCountrySelect = document.getElementById('editChurchCountrySelect');
    if(editChurchCountrySelect) {
        editChurchCountrySelect.addEventListener('change', function() {
            const churchSelect = document.getElementById('editChurchSelect');
            if(!churchSelect) return;
            churchSelect.innerHTML = '<option value="">-- Choose Church --</option>';
            const country = countries.find(c => c.name === this.value);
            country?.churches.forEach(ch => { churchSelect.innerHTML += `<option value="${escapeHtml(ch.name)}">${escapeHtml(ch.name)}</option>`; });
        });
    }

    const editChurchSelect = document.getElementById('editChurchSelect');
    if(editChurchSelect) {
        editChurchSelect.addEventListener('change', function() {
            const details = liveData.churchDetails[this.value] || {};
            const elYear = document.getElementById('editChurchYear');
            const elAttendees = document.getElementById('editChurchAttendees');
            if(elYear) elYear.value = details.yearStarted || '';
            if(elAttendees) elAttendees.value = details.attendees || '';
        });
    }

    const formEditChurch = document.getElementById('formEditChurch');
    if(formEditChurch) {
        formEditChurch.addEventListener('submit', async function(e) {
            e.preventDefault();
            const chName    = document.getElementById('editChurchSelect').value;
            const year      = document.getElementById('editChurchYear').value;
            const attendees = document.getElementById('editChurchAttendees').value;
            const gId       = liveData.dtGroupIds[chName];
            const btn = this.querySelector('.submit-btn');
            setSaving(btn, true, 'Update Church');
            try {
                if (gId) {
                    const payload = {};
                    if (attendees) payload.member_count = parseInt(attendees);
                    if (year)      payload.start_date   = `${year}-01-01`;
                    await dtFetch(`/dt-posts/v2/groups/${gId}`, 'PATCH', payload);
                }
                if (!liveData.churchDetails[chName]) liveData.churchDetails[chName] = {};
                liveData.churchDetails[chName].yearStarted = year || null;
                liveData.churchDetails[chName].attendees   = attendees || null;
                showToast(`Updated "${chName}"`, 'success');
                this.reset();
            } catch (err) {
                console.error(err);
                showToast('Failed to save changes — see console', 'error');
            } finally { setSaving(btn, false, 'Update Church'); }
        });
    }

    const editStaffChurchSelect = document.getElementById('editStaffChurchSelect');
    if(editStaffChurchSelect) {
        editStaffChurchSelect.addEventListener('change', function() {
            const staffSelect = document.getElementById('editStaffSelect');
            if(!staffSelect) return;
            staffSelect.innerHTML = '<option value="">-- Choose Staff Member --</option>';
            (liveData.staffDetails[this.value] || []).forEach((st, idx) => {
                staffSelect.innerHTML += `<option value="${idx}">${escapeHtml(st.name)}</option>`;
            });
        });
    }

    const editStaffSelect = document.getElementById('editStaffSelect');
    if(editStaffSelect) {
        editStaffSelect.addEventListener('change', function() {
            const chName = document.getElementById('editStaffChurchSelect').value;
            if (!chName || this.value === '') return;
            const s = (liveData.staffDetails[chName] || [])[this.value];
            if (!s) return;
            
            const elAge = document.getElementById('editStaffAge');
            const elYear = document.getElementById('editStaffYear');
            const elEvang = document.getElementById('editStaffEvangelism');
            const elSalvation = document.getElementById('editStaffSalvation');
            const elBaptism = document.getElementById('editStaffBaptism');

            if(elAge) elAge.value = s.age || '';
            if(elYear) elYear.value = s.yearJoined || '';
            if(elEvang) elEvang.value = s.discipleship?.evangelism || 'None';
            if(elSalvation) elSalvation.value  = s.discipleship?.salvation  || 'None';
            if(elBaptism) elBaptism.value    = s.discipleship?.baptism    || 'None';
        });
    }

    const formEditStaff = document.getElementById('formEditStaff');
    if(formEditStaff) {
        formEditStaff.addEventListener('submit', async function(e) {
            e.preventDefault();
            const chName   = document.getElementById('editStaffChurchSelect').value;
            const staffIdx = document.getElementById('editStaffSelect').value;
            if (!chName || staffIdx === '') return;
            const staff = (liveData.staffDetails[chName] || [])[staffIdx];
            const eLvl  = document.getElementById('editStaffEvangelism').value;
            const sLvl  = document.getElementById('editStaffSalvation').value;
            const bLvl  = document.getElementById('editStaffBaptism').value;
            const age   = document.getElementById('editStaffAge').value;
            const cId   = liveData.dtContactIds[staff.name];
            const btn = this.querySelector('.submit-btn');
            setSaving(btn, true, 'Update Staff');
            try {
                if (cId) {
                    await dtFetch(`/dt-posts/v2/contacts/${cId}`, 'PATCH', {
                        evangelism: { values: discLabelToDTKeys(eLvl).map(k => ({ value: k })) },
                        salvation:  { values: discLabelToDTKeys(sLvl).map(k => ({ value: k })) },
                        baptism:    { values: discLabelToDTKeys(bLvl).map(k => ({ value: k })) },
                        ...(age ? { age_range: age } : {})
                    });
                }
                staff.age = age || null;
                staff.discipleship = { evangelism: eLvl, salvation: sLvl, baptism: bLvl };
                staff.discipleshipLevel = Math.max(1, Math.max(discLabelToIndex(eLvl), discLabelToIndex(sLvl), discLabelToIndex(bLvl)));
                showToast(`Updated "${staff.name}"`, 'success');
                this.reset();
            } catch (err) {
                console.error(err);
                showToast('Failed to save changes — see console', 'error');
            } finally { setSaving(btn, false, 'Update Staff'); }
        });
    }

    const toggleCountryList = document.getElementById('toggleCountryList');
    if(toggleCountryList) {
        toggleCountryList.addEventListener('click', e => {
            e.stopPropagation();
            const el = document.getElementById('countryList');
            if(!el) return;
            const visible = el.style.display !== 'none';
            el.style.display = visible ? 'none' : 'block';
            const btn = e.currentTarget;
            if(btn.lastChild) btn.lastChild.textContent = visible ? ' Show Country List' : ' Hide Country List';
        });
    }

    const exportGlobalCSV = document.getElementById('exportGlobalCSV');
    if(exportGlobalCSV) {
        exportGlobalCSV.addEventListener('click', () => {
            let csv = 'Country,Churches,Groups,Staff,Volunteers\n';
            Object.entries(liveData.countryStats).forEach(([name, s]) => {
                csv += `"${name}",${s.churches},${s.groups},${s.staff},${s.volunteers}\n`;
            });
            const a = Object.assign(document.createElement('a'), {
                href: URL.createObjectURL(new Blob([csv], { type:'text/csv' })),
                download: 'door-ministry-stats.csv'
            });
            a.click();
        });
    }
}

// ============================================================================
// 4. INITIALIZATION WRAPPER (Runs when WordPress DOM is ready)
// ============================================================================

document.addEventListener('DOMContentLoaded', function() {
    // 1. Initialize the map container and layers
    initMap();
    
    // 2. Attach all UI event listeners safely
    setupEventListeners();
    
    // 3. Apply saved theme
    initTheme();
    
    // 4. Render empty dashboard while loading
    renderGlobalDashboard();  
    
    // 5. Kick off the DiscipleTools API fetch
    loadLiveData();           
    
    console.log('🌍 DOOR International Ministry Map v3.0.0 — DiscipleTools integration active');
});